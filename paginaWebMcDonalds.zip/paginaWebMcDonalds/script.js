/* Código para el requisito 1 */
let catalogo = document.getElementById('catalogo'),
    item_select = document.getElementById('item-select'),
    img_select = document.getElementById('img'),
    product_select = document.getElementById('product'),
    description = document.getElementById('description'),
    price_product = document.getElementById('price')

function cargar(item) {
    quitarBordes()
    catalogo.style.width = "60%"
    item_select.style.width = "40%"
    item_select.style.opacity = "1"
    item_select.style.visibility = "visible"
    item.style.border = "2px solid orange"

    img_select.src = item.getElementsByTagName("img")[0].src

    product_select.innerHTML = item.getElementsByTagName("p")[0].innerHTML

    description.innerHTML = "Descripción producto"

    price_product.innerHTML = item.getElementsByTagName("span")[0].innerHTML
}

function quitarBordes() {
    var items = document.getElementsByClassName("item")
    for (i = 0; i < items.length; i++) {
        items[i].style.border = "none"
    }
}

function cerrar() {
    catalogo.style.width = "100%"
    item_select.style.width = "0%"
    item_select.style.opacity = "0"
    item_select.style.visibility = "hidden"
    quitarBordes()
}

/* Código para el requisito 2 */
const $btnSignIn = document.querySelector('.sign-in-btn'),
    $btnSignUp = document.querySelector('.sign-up-btn'),
    $signIn = document.querySelector('.sign-in'),
    $signUp = document.querySelector('.sign-up')

document.addEventListener('click', e => {
    if (e.target === $btnSignIn || e.target === $btnSignUp) {
        $signIn.classList.toggle('active')
        $signUp.classList.toggle('active')
    }
})

/* Código para el requisito 4 */
if (document.readyState == 'loading') {
    carritoVacio()
    document.addEventListener('DOMContentLoaded', ready)
} else {
    ready()
    carritoVacio()
}

function ready() {
    var car_btn_delete_item = document.getElementsByClassName('btn-delete')
    for (var i = 0; i < car_btn_delete_item.length; i++) {
        var btn = car_btn_delete_item[i]
        btn.addEventListener('click', eliminarItemCarrito)
    }

    var car_btn_sumar_cantidad = document.getElementsByClassName('sumar-cant')
    for (var i = 0; i < car_btn_sumar_cantidad.length; i++) {
        var car_btns_cant = car_btn_sumar_cantidad[i]
        car_btns_cant.addEventListener('click', sumarCantidad)
    }

    var car_btn_restar_cantidad = document.getElementsByClassName('restar-cant')
    for (var i = 0; i < car_btn_restar_cantidad.length; i++) {
        var car_btns_cant = car_btn_restar_cantidad[i]
        car_btns_cant.addEventListener('click', restarCantidad)
    }

    document.getElementsByClassName('car-btn-pay')[0].addEventListener('click', botonPagarClicked)

}

document.getElementById('btn-agregar-al-carrito').addEventListener('click', function (event) {
    event.preventDefault()
    var precio = document.getElementsByClassName('precioProducto')[0].innerText
    var titulo = document.getElementsByClassName('tituloProducto')[0].innerText
    var imageSrc = document.getElementsByClassName('imagenProducto')[0].src

    agregarItemAlCarrito(imageSrc, titulo, precio)
    activarScrollEnCarItems()
})

function eliminarItemCarrito(event) {
    var car_btnClicked = event.target
    car_btnClicked.parentElement.remove()
    actualizarTotalCarrito()
    carritoVacio()
}

function actualizarTotalCarrito() {
    var car_carritoContenedor = document.getElementsByClassName('container-shopping-car')[0]
    var car_carritoItems = car_carritoContenedor.getElementsByClassName('car-item')
    var car_total = 0

    for (var i = 0; i < car_carritoItems.length; i++) {
        var car_item = car_carritoItems[i]
        var car_precioProducto = car_item.getElementsByClassName('car-item-price')[0]
        var car_precio = parseFloat(car_precioProducto.innerText.replace('$', '').replace('.', ''))
        var car_cantidadItem = car_item.getElementsByClassName('car-item-cant')[0]
        var car_cantidad = car_cantidadItem.value
        car_total = car_total + (car_precio * car_cantidad)
    }

    car_total = Math.round(car_total * 100) / 100
    document.getElementsByClassName('car-price-total')[0].innerText = '$' + car_total.toLocaleString("es")
}

function carritoVacio() {
    var car_carritoItems = document.getElementsByClassName('car-items')[0]
    var carritoVacioMsg = document.getElementById('carrito-vacio')
    if (car_carritoItems.childElementCount == 0) {
        carritoVacioMsg.style.display = 'block'
    } else {
        carritoVacioMsg.style.display = 'none'
    }
}

function sumarCantidad(event) {
    var car_btn_cant_clicked = event.target
    var car_selector = car_btn_cant_clicked.parentElement
    var car_cant_actual = car_selector.getElementsByClassName('car-item-cant')[0].value
    if (car_cant_actual < 10) {
        car_cant_actual++
        car_selector.getElementsByClassName('car-item-cant')[0].value = car_cant_actual
        actualizarTotalCarrito()
    } else {
        alert('¡Para ordenar más de 10 productos (de un mismo producto) haga una orden nueva!')
    }
}

function restarCantidad(event) {
    var car_btn_cant_clicked = event.target
    var car_selector = car_btn_cant_clicked.parentElement
    var car_cant_actual = car_selector.getElementsByClassName('car-item-cant')[0].value
    if (car_cant_actual >= 1) {
        car_cant_actual--
        car_selector.getElementsByClassName('car-item-cant')[0].value = car_cant_actual
        actualizarTotalCarrito()
    } else {
        event.target.closest('.car-item').remove()
        carritoVacio()
    }
}

function activarScrollEnCarItems() {
    var div = document.getElementById('car-items')

    var altura = div.offsetHeight

    var maxHeight = 300

    if (altura >= maxHeight) {
        div.style.overflowY = 'scroll'
    } else {
        div.style.overflowY = 'none'
    }
}

function agregarItemAlCarrito(imagen, titulo, precio) {
    var item = document.createElement('div')
    item.className = 'car-item'
    console.log(titulo)
    var itemsCarrito = document.getElementById('car-items')
    var nombreItemsCarrito = itemsCarrito.querySelectorAll('.car-item-title')
    console.log(nombreItemsCarrito.length)
    for (var i = 0; i < nombreItemsCarrito.length; i++) {
        console.log(i)
        var elemento = nombreItemsCarrito[i]
        var textoElemento = elemento.textContent || elemento.innerText
        if (textoElemento === titulo) {
            alert('¡El producto ya se encuentra en el carrito!')
            return
        }
    }

    var codigoHtmlItemCarrito = `
    <img src="${imagen}" alt="" width="80px">
    <div class="car-item-details">
        <span class="car-item-title">${titulo}</span>
        <div class="selector-cant">
            <i class='bx bx-minus restar-cant'></i>
            <input type="text" value="1" class="car-item-cant" disabled>
            <i class='bx bx-plus sumar-cant'></i>
        </div>
        <span class="car-item-price">${precio}</span>
    </div>
    <span class="btn-delete">
        <i class='bx bxs-trash-alt'></i>
    </span>
    `

    item.innerHTML = codigoHtmlItemCarrito
    itemsCarrito.append(item)

    item.getElementsByClassName('btn-delete')[0].addEventListener('click', eliminarItemCarrito)

    var car_btn_sumar_cantidad_nuevo = item.getElementsByClassName('sumar-cant')[0]
    car_btn_sumar_cantidad_nuevo.addEventListener('click', sumarCantidad)

    var car_btn_restar_cantidad_nuevo = item.getElementsByClassName('restar-cant')[0]
    car_btn_restar_cantidad_nuevo.addEventListener('click', restarCantidad)
    carritoVacio()
    actualizarTotalCarrito()
    alert('¡Producto agregado a tu carrito!')
}

function botonPagarClicked(event) {
    var car_carritoItems = document.getElementsByClassName('car-items')[0]

    if (car_carritoItems.childElementCount > 0) {
        alert('¡Gracias por tu compra!')

        var carritoItems = document.getElementsByClassName('car-items')[0]
        while (carritoItems.hasChildNodes()) {
            carritoItems.removeChild(carritoItems.firstChild)
        }
        carritoVacio()
        actualizarTotalCarrito()
    } else if (car_carritoItems.childElementCount == 0) {
        alert('¡Carrito vacío!')
    }



}

/* Código para el requisito 5 */

var contenidoNumeroTarjetaAux

const tarjeta = document.querySelector('#tarjeta'),
    btnAbrirFormulario = document.querySelector('#btn-abrir-formulario'),
    formulario = document.querySelector('#formulario-tarjeta'),
    numeroTarjeta = document.querySelector('#tarjeta .numero'),
    nombreTarjeta = document.querySelector('#tarjeta .nombre'),
    logoMarca = document.querySelector('#logo-marca'),
    firma = document.querySelector('#tarjeta .firma p'),
    mesExpiracion = document.querySelector('#tarjeta .mes'),
    yearExpiracion = document.querySelector('#tarjeta .year'),
    ccv = document.querySelector('#tarjeta .ccv'),
    btnGuardarInformacionTarjeta = document.querySelector('#btn-guardar-tarjeta'),
    numeroTarjetaInput = document.querySelector('#inputNumero'),
    nombreTarjetaInput = document.querySelector('#inputNombre'),
    mesSeleccionadoLista = document.querySelector('#selectMes'),
    yearSeleccionadoLista = document.querySelector('#selectYear'),
    ccvSeleccionadoLista = document.querySelector('#inputCCV')

const mostrarFrente = () => {
    if (tarjeta.classList.contains('active')) {
        tarjeta.classList.remove('active')
    }
}

btnGuardarInformacionTarjeta.addEventListener('click', () => {
    if (logoMarca.querySelector('img') && logoMarca.querySelector('img').getAttribute('src') !== null) {
        if (mesExpiracion.innerText != 'MM') {
            if (yearExpiracion.innerText != 'AA') {
                console.log(numeroTarjetaInput.innerText.length)
                if (numeroTarjeta.innerText != '#### #### #### ####' && numeroTarjetaInput.value.length == 19) {
                    if (nombreTarjeta.innerText != 'JHON DOE' && nombreTarjetaInput.value.length >= 5) {
                        if (ccv.innerText != '' && ccv.innerText.length == 3) {
                            alert('¡Información guardada!')
                            numeroTarjeta.innerText = '#### #### #### ####'
                            nombreTarjeta.innerText = 'JHON DOE'
                            logoMarca.innerHTML = ''
                            mesExpiracion.innerText = 'MM'
                            yearExpiracion.innerText = 'AA'
                            firma.innerText = ''
                            ccv.innerText = ''
                            numeroTarjetaInput.value = ''
                            nombreTarjetaInput.value = ''
                            mesSeleccionadoLista.value = 'Mes'
                            yearSeleccionadoLista.value = 'Año'
                            ccvSeleccionadoLista.value = ''
                            mostrarFrente()
                        } else {
                            alert('¡Escriba los tres números CCV de su tarjeta!')
                        }
                    } else {
                        alert('¡Escriba un nombre mayor a 5 caracteres!')
                    }
                } else {
                    alert('¡Escriba los 16 digítos de su tarjeta!')
                }
            } else {
                alert('¡Seleccione un año válido!')
            }
        } else {
            alert('¡Seleccione un mes válido!')
        }
    } else {
        alert('¡Por el momento solo aceptamos Visa y MasterCard!')
    }
})

tarjeta.addEventListener('click', () => {
    tarjeta.classList.toggle('active')
})

btnAbrirFormulario.addEventListener('click', () => {
    btnAbrirFormulario.classList.toggle('active')
    formulario.classList.toggle('active')
})

for (let i = 1; i <= 12; i++) {
    let opcion = document.createElement('option')
    opcion.value = i
    opcion.innerText = i
    formulario.selectMes.appendChild(opcion)
}

const yearActual = new Date().getFullYear()
for (let i = yearActual; i <= yearActual + 8; i++) {
    let opcion = document.createElement('option')
    opcion.value = i
    opcion.innerText = i
    formulario.selectYear.appendChild(opcion)
}


formulario.inputNumero.addEventListener('keyup', (e) => {
    let valorInput = e.target.value

    formulario.inputNumero.value = valorInput.replace(/\s/g, '')
        .replace(/\D/g, '').replace(/([0-9]{4})/g, '$1 ').trim()

    numeroTarjeta.textContent = valorInput

    if (valorInput == '') {
        numeroTarjeta.textContent = '#### #### #### ####'

        logoMarca.innerHTML = ''
    }

    if (contenidoNumeroTarjetaAux != valorInput) {
        logoMarca.innerHTML = ''
    }

    contenidoNumeroTarjetaAux = valorInput

    if (valorInput[0] == 4) {
        logoMarca.innerHTML = ''
        const imagen = document.createElement('img')
        imagen.src = 'imagenes/logos/visa.png'
        logoMarca.appendChild(imagen)
    } else if (valorInput[0] == 5) {
        logoMarca.innerHTML = ''
        const imagen = document.createElement('img')
        imagen.src = 'imagenes/logos/mastercard.png'
        logoMarca.appendChild(imagen)
    }

    mostrarFrente()
})

formulario.inputNombre.addEventListener('keyup', (e) => {
    let valorInput = e.target.value

    formulario.inputNombre.value = valorInput.replace(/[0-9]/g, '')
    nombreTarjeta.textContent = valorInput
    firma.textContent = valorInput
    if (valorInput == '') {
        nombreTarjeta.textContent = 'Jhon Doe'
    }

    mostrarFrente()
})

formulario.selectMes.addEventListener('change', (e) => {
    mesExpiracion.textContent = e.target.value
    mostrarFrente()
})

formulario.selectYear.addEventListener('change', (e) => {
    yearExpiracion.textContent = e.target.value.slice(2)
    mostrarFrente()
})

formulario.inputCCV.addEventListener('keyup', () => {
    if (!tarjeta.classList.contains('active')) {
        tarjeta.classList.toggle('active')
    }

    formulario.inputCCV.value = formulario.inputCCV.value.replace(/\s/g, '')
        .replace(/\D/g, '')

    ccv.textContent = formulario.inputCCV.value;
})

/* GO TOP */
window.onscroll = function () {
    if (document.documentElement.scrollTop > 100) {
        document.querySelector('.go-top-container')
            .classList.add('show')
    } else {
        document.querySelector('.go-top-container')
            .classList.remove('show')
    }
}

document.querySelector('.go-top-container')
    .addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        })
    })